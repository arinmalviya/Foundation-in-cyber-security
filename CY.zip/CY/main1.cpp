#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <iphlpapi.h>
#include <windows.h>

// Remove the #pragma comments and link manually through project options
// #pragma comment(lib, "ws2_32.lib")
// #pragma comment(lib, "iphlpapi.lib")

// Define necessary structures
typedef struct _IPHeader {
    unsigned char  iph_verlen;
    unsigned char  iph_tos;
    unsigned short iph_length;
    unsigned short iph_id;
    unsigned short iph_offset;
    unsigned char  iph_ttl;
    unsigned char  iph_protocol;
    unsigned short iph_checksum;
    unsigned int   iph_src;
    unsigned int   iph_dest;
} IPHeader;

typedef struct _TCPHeader {
    unsigned short th_sport;
    unsigned short th_dport;
    unsigned int   th_seq;
    unsigned int   th_ack;
    unsigned char  th_lenres;
    unsigned char  th_flags;
    unsigned short th_win;
    unsigned short th_sum;
    unsigned short th_urp;
} TCPHeader;

typedef struct _UDPHeader {
    unsigned short uh_sport;
    unsigned short uh_dport;
    unsigned short uh_length;
    unsigned short uh_checksum;
} UDPHeader;

#define SIO_RCVALL _WSAIOW(IOC_VENDOR,1)

void PrintIPAddress(unsigned int ip) {
    struct in_addr addr;
    addr.s_addr = ip;
    std::cout << inet_ntoa(addr);
}

int main() {
    WSADATA wsaData;
    SOCKET sock;
    char buffer[65536];
    int ret;

    std::cout << "Initializing Winsock...\n";
    if (WSAStartup(MAKEWORD(2,2), &wsaData) != 0) {
        std::cerr << "WSAStartup failed. Error: " << WSAGetLastError() << std::endl;
        return 1;
    }

    // Get network adapters
    PIP_ADAPTER_INFO pAdapterInfo;
    PIP_ADAPTER_INFO pAdapter = NULL;
    DWORD dwRetVal = 0;
    ULONG ulOutBufLen = sizeof(IP_ADAPTER_INFO);

    pAdapterInfo = (IP_ADAPTER_INFO *) malloc(sizeof(IP_ADAPTER_INFO));
    if (pAdapterInfo == NULL) {
        std::cerr << "Error allocating memory\n";
        WSACleanup();
        return 1;
    }

    // Make an initial call to GetAdaptersInfo to get the necessary size
    if (GetAdaptersInfo(pAdapterInfo, &ulOutBufLen) == ERROR_BUFFER_OVERFLOW) {
        free(pAdapterInfo);
        pAdapterInfo = (IP_ADAPTER_INFO *) malloc(ulOutBufLen);
        if (pAdapterInfo == NULL) {
            std::cerr << "Error allocating memory\n";
            WSACleanup();
            return 1;
        }
    }

    if ((dwRetVal = GetAdaptersInfo(pAdapterInfo, &ulOutBufLen)) != NO_ERROR) {
        std::cerr << "GetAdaptersInfo failed with error: " << dwRetVal << std::endl;
        free(pAdapterInfo);
        WSACleanup();
        return 1;
    }

    // List adapters
    std::cout << "Available network interfaces:\n";
    int i = 0;
    pAdapter = pAdapterInfo;
    while (pAdapter) {
        std::cout << ++i << ". " << pAdapter->Description << std::endl;
        pAdapter = pAdapter->Next;
    }

    if (i == 0) {
        std::cerr << "No network interfaces found!\n";
        free(pAdapterInfo);
        WSACleanup();
        return 1;
    }

    int choice;
    std::cout << "\nSelect interface (1-" << i << "): ";
    std::cin >> choice;

    pAdapter = pAdapterInfo;
    for (int j = 1; j < choice && pAdapter != NULL; j++) {
        pAdapter = pAdapter->Next;
    }

    if (pAdapter == NULL) {
        std::cerr << "Invalid selection!\n";
        free(pAdapterInfo);
        WSACleanup();
        return 1;
    }

    std::cout << "Selected: " << pAdapter->Description << std::endl;

    // Create raw socket
    sock = socket(AF_INET, SOCK_RAW, IPPROTO_IP);
    if (sock == INVALID_SOCKET) {
        std::cerr << "socket() failed. Error: " << WSAGetLastError() << std::endl;
        free(pAdapterInfo);
        WSACleanup();
        return 1;
    }

    // Bind to interface
    sockaddr_in sa;
    sa.sin_family = AF_INET;
    sa.sin_port = htons(0);
    sa.sin_addr.s_addr = inet_addr(pAdapter->IpAddressList.IpAddress.String);

    if (bind(sock, (sockaddr *)&sa, sizeof(sa)) == SOCKET_ERROR) {
        std::cerr << "bind() failed. Error: " << WSAGetLastError() << std::endl;
        closesocket(sock);
        free(pAdapterInfo);
        WSACleanup();
        return 1;
    }

    // Set promiscuous mode
    DWORD dwValue = 1;
    if (ioctlsocket(sock, SIO_RCVALL, &dwValue) == SOCKET_ERROR) {
        std::cerr << "ioctlsocket() failed. Error: " << WSAGetLastError() << std::endl;
        closesocket(sock);
        free(pAdapterInfo);
        WSACleanup();
        return 1;
    }

    free(pAdapterInfo);

    std::cout << "\nSniffing started... Press Ctrl+C to stop\n";
    std::cout << "============================================\n";

    // Main capture loop
    while (true) {
        ret = recv(sock, buffer, sizeof(buffer), 0);
        if (ret == SOCKET_ERROR) {
            std::cerr << "recv() failed. Error: " << WSAGetLastError() << std::endl;
            break;
        }

        if (ret < sizeof(IPHeader)) continue;

        IPHeader *ipHeader = (IPHeader *)buffer;
        int ipHeaderLength = (ipHeader->iph_verlen & 0x0F) * 4;

        std::cout << "Packet size: " << ret << " bytes | ";
        std::cout << "Protocol: ";

        switch (ipHeader->iph_protocol) {
            case IPPROTO_TCP: std::cout << "TCP"; break;
            case IPPROTO_UDP: std::cout << "UDP"; break;
            case IPPROTO_ICMP: std::cout << "ICMP"; break;
            default: std::cout << "Other"; break;
        }

        std::cout << " | Source: ";
        PrintIPAddress(ipHeader->iph_src);
        std::cout << " -> Destination: ";
        PrintIPAddress(ipHeader->iph_dest);
        std::cout << std::endl;
    }

    closesocket(sock);
    WSACleanup();
    return 0;
}